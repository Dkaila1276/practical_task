var string = "Hello123@";

//1.Return the A-Z./
var findCap = string.match(/[A-Z]/g).join("");
console.log(findCap);
//2.Return the a-z.
var findsmall = string.match(/[a-z]/g).join("");
console.log(findsmall);
//3.Return the 0-9.
// console.log("-----Return the 0-9.--------")
var findnum = string.match(/[0-9]/g).join("");
console.log(findnum);


//4.Return only special characters.
var findSpec = string.match(/[^A-Za-z0-9]/g).join("");
console.log(findSpec);
//5.Return only vowels (a, e, i, o, u)
// console.log("----------Return only vowels (a, e, i, o, u)----------");
var findvowels = string.match(/[aeiou]/g).join("");
console.log(findvowels);

//6.Return only consonants.
var findvowels = string.match(/[^aeiou0-9]/g).join("");
console.log(findvowels);


//7.Print characters/digits at odd positions.
var splitString = string.split(" ");
var convertString = [];
for( let i = 0 ; i < splitString.length;i++){
    if(splitString[i]/2 == 0){
        convertString.push(splitString[i]);
      console.log(convertString)
}
}
//8.Print characters/digits at even positions.

// 9.Reverse the input.  
console.log("-------Reverse the input.---------")
var revString = string.split("").reverse().join("");
console.log(revString , "revString"); 
//10.Find the second last character/digit/number in the input.
console.log("-----Find the second last character/digit/number in the input.-------------------")
const arraystring = string.split("");
console.log(arraystring[arraystring.length-2]);
